package com.sapient.pkg;

public class Greeting {
	
	private String greet;

	public Greeting() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Greeting(String greet) {
		super();
		this.greet = greet;
	}

	public String getGreet() {
		return greet;
	}

	public void setGreet(String greet) {
		this.greet = greet;
	}
	
}
